package com.github.sacsar.hellodiceroller.mainmenu;

import androidx.lifecycle.ViewModel;

public class MainMenuViewModel extends ViewModel {
  // TODO: Implement the ViewModel
}
